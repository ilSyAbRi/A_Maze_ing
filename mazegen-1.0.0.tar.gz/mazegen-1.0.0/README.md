# 🧩 A-Maze-ing
> Python maze generator & solver — 42 curriculum project by `ibet-lot` & `ilsyabri`

---

## ⚙️ Quick Start

```bash
make install && make run
# or
python3 a_maze_ing.py config.txt
```

## 📄 Config File

```ini
# Required
WIDTH=20
HEIGHT=20
ENTRY=0,0
EXIT=19,19
OUTPUT_FILE=out.txt
PERFECT=True

# Optional
SEED=42
```

---

## 🧠 Algorithms

| Step | Algorithm | Why |
|------|-----------|-----|
| Generation | DFS – Recursive Backtracking | Simple, efficient, produces perfect mazes |
| Solving | BFS – Breadth-First Search | Guarantees shortest path from entry to exit |

---

## 📦 Reusable Module

The `MazeGenerator` class can be imported into any project.

- Custom width & height
- Reproducible seeds
- Maze grid access
- Solution path output
- MLX rendering

---

## 👥 Team

| Member | Responsibilities |
|--------|-----------------|
| `ibet-lot` | MLX visualization, animations, menu, Makefile, packaging |
| `ilsyabri` | DFS generation, BFS solving, imperfect maze, parsing, output |

---

## 🔁 Retrospective

**What worked well**
- Clear separation of tasks between teammates
- Efficient DFS + BFS implementation
- Working graphical MLX visualization

**What could be improved**
- Add more algorithms (Prim, Kruskal)
- Better performance on large mazes
- UI improvements

---

## 🛠️ Tools

`Python 3.10+` · `MiniLibX` · `flake8` · `mypy`